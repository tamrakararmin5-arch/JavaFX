package application;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Layer - handles ALL database operations.
 * No JavaFX code here. Main.java calls these methods and never writes SQL directly.
 */
public class DatabaseHelper {

    // Update DB_PASS if your MySQL root password is different
    private static final String DB_URL =
        "jdbc:mysql://localhost:3306/dbconnect"
        + "?useSSL=false&allowPublicKeyRetrieval=true"
        + "&serverTimezone=UTC&autoReconnect=true";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "@rmintask2008";

    // Opens a connection with auto-commit always ON
    public Connection getConnection() throws SQLException {
        Connection c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
        c.setAutoCommit(true);
        return c;
    }

    // Prints DB diagnostics to Eclipse console on startup. Returns false if unreachable.
    public boolean verifyConnection() {
        try (Connection c = getConnection()) {
            DatabaseMetaData m = c.getMetaData();
            System.out.println("Connected: " + m.getDatabaseProductName()
                + " " + m.getDatabaseProductVersion()
                + " | Catalog: " + c.getCatalog());
            ResultSet rs = c.createStatement().executeQuery("SELECT COUNT(*) FROM users");
            if (rs.next()) System.out.println("Users in DB: " + rs.getInt(1));
            return true;
        } catch (SQLException e) {
            System.err.println("CONNECTION FAILED: " + e.getMessage());
            return false;
        }
    }

    // Creates all 4 tables on first run. Safe to call every launch (IF NOT EXISTS).
    public void initTables() {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS users ("
            + "id INT AUTO_INCREMENT PRIMARY KEY,"
            + "username VARCHAR(50) NOT NULL UNIQUE,"
            + "password VARCHAR(50) NOT NULL)",

            "CREATE TABLE IF NOT EXISTS books ("
            + "id INT AUTO_INCREMENT PRIMARY KEY,"
            + "title VARCHAR(255) UNIQUE, author VARCHAR(255),"
            + "genre VARCHAR(100), pages INT, description TEXT)",

            "CREATE TABLE IF NOT EXISTS favourites ("
            + "id INT AUTO_INCREMENT PRIMARY KEY,"
            + "user_id INT NOT NULL, book_title VARCHAR(255) NOT NULL,"
            + "UNIQUE KEY uq_fav (user_id, book_title),"
            + "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)",

            "CREATE TABLE IF NOT EXISTS reviews ("
            + "id INT AUTO_INCREMENT PRIMARY KEY,"
            + "user_id INT NOT NULL, book_title VARCHAR(255) NOT NULL,"
            + "rating INT NOT NULL, review_text TEXT,"
            + "UNIQUE KEY uq_review (user_id, book_title),"
            + "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)"
        };
        try (Connection c = getConnection(); Statement s = c.createStatement()) {
            for (String sql : ddl) s.execute(sql);
        } catch (SQLException e) {
            System.err.println("initTables: " + e.getMessage());
        }
    }

    // ── Books ─────────────────────────────────────────────────────────────────

    // Loads all books ordered by average rating DESC (drives Trending section)
    public List<Book> loadBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.title, b.author, b.genre, b.pages, b.description "
                   + "FROM books b LEFT JOIN reviews r ON r.book_title = b.title "
                   + "GROUP BY b.id, b.title, b.author, b.genre, b.pages, b.description "
                   + "ORDER BY AVG(COALESCE(r.rating,0)) DESC, b.title ASC";
        try (Connection c = getConnection();
             ResultSet  rs = c.createStatement().executeQuery(sql)) {
            while (rs.next())
                books.add(new Book(rs.getString("title"), rs.getString("author"),
                    rs.getString("genre"), rs.getInt("pages"), rs.getString("description")));
        } catch (SQLException e) {
            System.err.println("loadBooks: " + e.getMessage());
        }
        return books;
    }

    // Inserts a new book. Throws on duplicate title or other DB error.
    public void addBook(String title, String author, String genre,
                        int pages, String desc) throws SQLException {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO books (title,author,genre,pages,description) VALUES(?,?,?,?,?)")) {
            ps.setString(1, title); ps.setString(2, author);
            ps.setString(3, genre); ps.setInt(4, pages); ps.setString(5, desc);
            ps.executeUpdate();
        }
    }

    // ── Authentication ────────────────────────────────────────────────────────

    // Returns the user's DB id on match, or -1 if credentials are wrong
    public int loginUser(String username, String password) throws SQLException {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT id FROM users WHERE username=? AND password=?")) {
            ps.setString(1, username); ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getInt("id") : -1;
        }
    }

    // Inserts a new user and returns their auto-generated ID
    public int registerUser(String username, String password) throws SQLException {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO users (username,password) VALUES(?,?)",
                 Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username); ps.setString(2, password);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            return keys.next() ? keys.getInt(1) : -1;
        }
    }

    // Returns all users as "ID: X   Username: Y" strings for the Admin Panel
    public List<String> getAllUsers() {
        List<String> list = new ArrayList<>();
        try (Connection c = getConnection();
             ResultSet rs = c.createStatement()
                 .executeQuery("SELECT id, username FROM users ORDER BY id")) {
            while (rs.next())
                list.add("ID: " + rs.getInt("id") + "   Username: " + rs.getString("username"));
        } catch (SQLException e) {
            System.err.println("getAllUsers: " + e.getMessage());
        }
        return list;
    }

    // ── Favourites ────────────────────────────────────────────────────────────

    public List<String> getFavourites(int userId) {
        List<String> list = new ArrayList<>();
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT book_title FROM favourites WHERE user_id=?")) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(rs.getString("book_title"));
        } catch (SQLException e) {
            System.err.println("getFavourites: " + e.getMessage());
        }
        return list;
    }

    public boolean isFavourite(int userId, String title) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT id FROM favourites WHERE user_id=? AND book_title=?")) {
            ps.setInt(1, userId); ps.setString(2, title);
            return ps.executeQuery().next();
        } catch (SQLException e) { return false; }
    }

    // INSERT IGNORE prevents duplicate errors if button clicked twice
    public void addFavourite(int userId, String title) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT IGNORE INTO favourites (user_id,book_title) VALUES(?,?)")) {
            ps.setInt(1, userId); ps.setString(2, title); ps.executeUpdate();
        } catch (SQLException e) { System.err.println("addFavourite: " + e.getMessage()); }
    }

    public void removeFavourite(int userId, String title) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "DELETE FROM favourites WHERE user_id=? AND book_title=?")) {
            ps.setInt(1, userId); ps.setString(2, title); ps.executeUpdate();
        } catch (SQLException e) { System.err.println("removeFavourite: " + e.getMessage()); }
    }

    // ── Reviews & Ratings ─────────────────────────────────────────────────────

    public double getAverageRating(String title) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT AVG(rating) FROM reviews WHERE book_title=?")) {
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) { System.err.println("getAvgRating: " + e.getMessage()); }
        return 0.0;
    }

    // Fills ratingOut[0] and textOut[0] with the user's existing review (if any)
    public void getUserReview(int userId, String title, int[] ratingOut, String[] textOut) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT rating,review_text FROM reviews WHERE user_id=? AND book_title=?")) {
            ps.setInt(1, userId); ps.setString(2, title);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ratingOut[0] = rs.getInt("rating");
                textOut[0] = rs.getString("review_text") != null ? rs.getString("review_text") : "";
            }
        } catch (SQLException e) { System.err.println("getUserReview: " + e.getMessage()); }
    }

    // ON DUPLICATE KEY UPDATE means re-submitting edits rather than creating duplicates
    public void saveReview(int userId, String title, int rating, String text) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO reviews (user_id,book_title,rating,review_text) VALUES(?,?,?,?) "
               + "ON DUPLICATE KEY UPDATE rating=VALUES(rating),review_text=VALUES(review_text)")) {
            ps.setInt(1, userId); ps.setString(2, title);
            ps.setInt(3, rating); ps.setString(4, text);
            ps.executeUpdate();
        } catch (SQLException e) { System.err.println("saveReview: " + e.getMessage()); }
    }

    // Returns all reviews for a book as formatted strings: "username  ★★★★☆  text"
    public List<String> getAllReviews(String title) {
        List<String> list = new ArrayList<>();
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT u.username,r.rating,r.review_text FROM reviews r "
               + "JOIN users u ON r.user_id=u.id WHERE r.book_title=? ORDER BY r.id DESC")) {
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String t = rs.getString("review_text");
                list.add(rs.getString("username") + "  " + starsString(rs.getInt("rating"))
                    + (t != null && !t.isEmpty() ? "  \"" + t + "\"" : ""));
            }
        } catch (SQLException e) { System.err.println("getAllReviews: " + e.getMessage()); }
        return list;
    }

    // Converts a numeric rating to a 5-star Unicode string e.g. 4 → "★★★★☆"
    public String starsString(double rating) {
        int full = (int) Math.round(rating);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) sb.append(i < full ? "\u2605" : "\u2606");
        return sb.toString();
    }
}